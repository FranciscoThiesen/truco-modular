
/***************************************************************************
*  $MCI M�dulo de implementa��o: TLIS Teste lista de s�mbolos
*
*  Arquivo gerado:              TestLIS.c
*  Letras identificadoras:      TLIS
*
*  Nome da base de software:    Arcabou�o para a automa��o de testes de programas redigidos em C
*  Arquivo da base de software: D:\AUTOTEST\PROJETOS\LISTA.BSW
*
*  Projeto: INF 1301 / 1628 Automatiza��o dos testes de m�dulos C
*  Gestor:  LES/DI/PUC-Rio
*  Autores: avs
*
*  $HA Hist�rico de evolu��o:
*     Vers�o  Autor    Data     Observa��es
*     4       avs   01/fev/2006 criar linguagem script simb�lica
*     3       avs   08/dez/2004 uniformiza��o dos exemplos
*     2       avs   07/jul/2003 unifica��o de todos os m�dulos em um s� projeto
*     1       avs   16/abr/2003 in�cio desenvolvimento
*
***************************************************************************/

#include    <string.h>
#include    <stdio.h>
#include    <malloc.h>

#include    "TST_Espc.h"

#include    "Generico.h"
#include    "LerParm.h"

#include "Baralho.h"
#include    "Lista.h"

static const char CRIAR_BARALHO_CMD           [ ] = "=criarbaralho"     ;
static const char ESVAZIA_BARALHO_CMD         [ ] = "=esvaziarbaralho"     ;
static const char DESTRUIR_BARALHO_CMD        [ ] = "=destruirbaralho"     ;
static const char EMBARALHAR_CMD              [ ] = "=embaralhar"     ;
static const char ADICIONAR_CARTA_CMD         [ ] = "=adicionarcarta"     ;
static const char ACHAR_CARTA_CMD             [ ] = "=acharcarta"     ;
static const char REMOVER_CARTA_CMD           [ ] = "=removercarta"     ;
static const char TIRAR_VIRA_CMD              [ ] = "=tirarvira"     ;

#define TRUE  1
#define FALSE 0

#define VAZIO     0
#define NAO_VAZIO 1

#define DIM_VT_LISTA   10
#define DIM_VALOR     100

LIS_tppLista   vtListas[ DIM_VT_LISTA ] ;

/***** Prot�tipos das fun��es encapuladas no m�dulo *****/

   static void DestruirValor( void * pValor ) ;

   static int ValidarInxLista( int inxLista , int Modo ) ;

/*****  C�digo das fun��es exportadas pelo m�dulo  *****/


/***********************************************************************
*
*  $FC Fun��o: TLIS &Testar lista
*
*  $ED Descri��o da fun��o
*     Podem ser criadas at� 10 listas, identificadas pelos �ndices 0 a 10
*
*     Comandos dispon�veis:
*
*     =resetteste
*           - anula o vetor de listas. Provoca vazamento de mem�ria
*     =criarlista                   inxLista
*     =destruirlista                inxLista
*     =esvaziarlista                inxLista
*     =inselemantes                 inxLista  string  CondRetEsp
*     =inselemapos                  inxLista  string  CondRetEsp
*     =obtervalorelem               inxLista  string  CondretPonteiro
*     =excluirelem                  inxLista  CondRetEsp
*     =irinicio                     inxLista
*     =irfinal                      inxLista
*     =avancarelem                  inxLista  numElem CondRetEsp
*
***********************************************************************/

TST_tpCondRet TST_EfetuarComando( char * ComandoTeste )
{

	int inxLista  = -1 ,
          numLidos   = -1 ,
          CondRetEsp = -1  ;

      TST_tpCondRet CondRet ;

      char   StringDado[ DIM_VALOR ] ;
      char * pDado ;

      int ValEsp = -1 ;

      int i ;

      int numElem = -1 ;

      StringDado[ 0 ] = 0 ;



	if ( strcmp( ComandoTeste , CRIAR_BARALHO_CMD ) == 0 )
	{
		numLidos = LER_LerParametros( "i" ,
                       &inxLista ) ;

            if ( ( numLidos != 1 ) || ( ! ValidarInxLista( inxLista , VAZIO )))
            {
               return TST_CondRetParm ;
            } /* if */

            vtListas[ inxLista ] =  BAR_NovoBaralhoEmbaralhado() ;//LIS_CriarLista( DestruirValor ) ;

            return TST_CompararPonteiroNulo( 1 , vtListas[ inxLista ] ,
               "Erro em ponteiro de nova lista."  ) ;
	}
	else if ( strcmp( ComandoTeste , ESVAZIA_BARALHO_CMD ) == 0 )
	{
	
	}
	else if ( strcmp( ComandoTeste , DESTRUIR_BARALHO_CMD ) == 0 )
	{
	
	}
	else if ( strcmp( ComandoTeste , EMBARALHAR_CMD ) == 0 )
	{
	
	}
	else if ( strcmp( ComandoTeste , ADICIONAR_CARTA_CMD ) == 0 )
	{
	
	}
	else if ( strcmp( ComandoTeste , ACHAR_CARTA_CMD ) == 0 )
	{
	
	}
	else if ( strcmp( ComandoTeste , REMOVER_CARTA_CMD ) == 0 )
	{
	
	}
	else if ( strcmp( ComandoTeste , TIRAR_VIRA_CMD ) == 0 )
	{
	
	}
}