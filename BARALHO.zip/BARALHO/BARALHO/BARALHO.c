// BARALHO2.cpp : Defines the entry point for the console application.
//
#include <stdio.h>
#include <malloc.h>
#include "LISTA.h"

 typedef struct carta 
 {
	 int naipe;
	 int valor ;
 }BRL_carta;

  

//static LIS_tppLista PreencheBaralho(LIS_tppLista baralho);

void Destruir(void * var )
{
	free(var) ;
}

void CriarBaralho()
{ 
	unsigned int i=0; LIS_tppLista baralho; BRL_carta  carta ;
    BRL_carta* card;
	baralho = LIS_CriarLista( Destruir ) ;
	for(i = 0; i < 40; i++)
	{
		carta.naipe = i%5 ;
		carta.valor = i%5 ;
		LIS_InserirElementoApos( baralho, &carta) ;
		printf("%d\n", card->naipe ) ;
	}

	//printf("%d\n", card->naipe ) ;   //LIS_ObterValor(baralho)
}



int main(void)
{
	CriarBaralho();
	
	system("pause") ;
	return ;
}
